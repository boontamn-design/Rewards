import React from "react";
import { Delete } from "lucide-react";

interface OnScreenKeypadProps {
  value: string;
  onChange: (value: string) => void;
  maxLength?: number;
  disabled?: boolean;
  showValue?: boolean;
}

export function OnScreenKeypad({ value, onChange, maxLength = 6, disabled = false, showValue = true }: OnScreenKeypadProps) {
  const handlePress = (key: string) => {
    if (disabled) return;
    if (key === "delete") {
      onChange(value.slice(0, -1));
    } else {
      if (value.length < maxLength) {
        onChange(value + key);
      }
    }
  };

  const keys = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "delete"];

  return (
    <div className="space-y-4">
      {showValue && (
        <div className="flex justify-center gap-3 py-2">
          {Array.from({ length: maxLength }).map((_, i) => (
            <div
              key={i}
              className={`w-4 h-4 rounded-full border-2 transition-all duration-200 ${
                i < value.length
                  ? "bg-yellow-500 border-yellow-500 scale-110"
                  : "border-yellow-500/40"
              }`}
            />
          ))}
        </div>
      )}
      <div className="grid grid-cols-3 gap-3 max-w-xs mx-auto">
        {keys.map((key, index) => {
          if (key === "") {
            return <div key={index} />;
          }
          if (key === "delete") {
            return (
              <button
                key={index}
                type="button"
                onClick={() => handlePress("delete")}
                disabled={disabled || value.length === 0}
                className="keypad-button delete disabled:opacity-40"
              >
                <Delete size={20} />
              </button>
            );
          }
          return (
            <button
              key={index}
              type="button"
              onClick={() => handlePress(key)}
              disabled={disabled || value.length >= maxLength}
              className="keypad-button disabled:opacity-40"
            >
              {key}
            </button>
          );
        })}
      </div>
    </div>
  );
}
