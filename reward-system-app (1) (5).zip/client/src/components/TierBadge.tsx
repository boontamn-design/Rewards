import React from "react";
import { Crown, Star, Award } from "lucide-react";
import { cn } from "@/lib/utils";

interface TierBadgeProps {
  tierName: string;
  minPoints?: number;
  currentPoints?: number;
  className?: string;
}

function getTierIcon(name: string) {
  const lower = name.toLowerCase();
  if (lower === "platinum" || lower === "diamond") return <Crown size={16} />;
  if (lower === "gold" || lower === "silver") return <Star size={16} />;
  return <Award size={16} />;
}

function getTierStyle(name: string) {
  const lower = name.toLowerCase();
  if (lower === "platinum") return "platinum";
  if (lower === "gold") return "gold";
  if (lower === "silver") return "silver";
  return "bronze";
}

export function TierBadge({ tierName, minPoints, currentPoints, className }: TierBadgeProps) {
  const style = getTierStyle(tierName);
  return (
    <div className={cn("tier-badge", style, className)}>
      {getTierIcon(tierName)}
      <span>{tierName}</span>
      {currentPoints !== undefined && (
        <span className="text-xs opacity-70">({currentPoints.toLocaleString()} แต้ม)</span>
      )}
    </div>
  );
}
