import React from "react";
import { cn } from "@/lib/utils";

interface LuxuryCardProps {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
}

export function LuxuryCard({ children, className, hover = true }: LuxuryCardProps) {
  return (
    <div
      className={cn(
        "luxury-card p-6 transition-all duration-300",
        hover && "group hover:shadow-lg hover:shadow-yellow-500/20",
        className
      )}
    >
      {children}
    </div>
  );
}

interface LuxuryCardHeaderProps {
  children: React.ReactNode;
  className?: string;
}

export function LuxuryCardHeader({ children, className }: LuxuryCardHeaderProps) {
  return (
    <div className={cn("mb-4 pb-4 border-b border-yellow-500/20", className)}>
      {children}
    </div>
  );
}

interface LuxuryCardTitleProps {
  children: React.ReactNode;
  className?: string;
}

export function LuxuryCardTitle({ children, className }: LuxuryCardTitleProps) {
  return (
    <h2 className={cn("text-2xl font-bold text-gradient", className)}>
      {children}
    </h2>
  );
}

interface LuxuryCardContentProps {
  children: React.ReactNode;
  className?: string;
}

export function LuxuryCardContent({ children, className }: LuxuryCardContentProps) {
  return <div className={cn("space-y-4", className)}>{children}</div>;
}

interface LuxuryCardFooterProps {
  children: React.ReactNode;
  className?: string;
}

export function LuxuryCardFooter({ children, className }: LuxuryCardFooterProps) {
  return (
    <div className={cn("mt-6 pt-4 border-t border-yellow-500/20 flex gap-3", className)}>
      {children}
    </div>
  );
}
