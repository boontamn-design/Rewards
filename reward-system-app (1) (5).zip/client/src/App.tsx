import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

// Pages
import Home from "./pages/Home";
import Login from "./pages/Login";
import CustomerProfile from "./pages/CustomerProfile";
import RewardsShop from "./pages/RewardsShop";
import RedemptionStatus from "./pages/RedemptionStatus";

import AdminDashboard from "./pages/AdminDashboard";
import AdminRedemptionApproval from "./pages/AdminRedemptionApproval";
import AdminReports from "./pages/AdminReports";
import SuperAdminPanel from "./pages/SuperAdminPanel";

function Router() {
  return (
    <Switch>
      {/* Public */}
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />

      {/* Customer */}
      <Route path="/customer-profile" component={CustomerProfile} />
      <Route path="/rewards-shop" component={RewardsShop} />
      <Route path="/redemption-status" component={RedemptionStatus} />

      {/* Admin */}
      <Route path="/admin-dashboard" component={AdminDashboard} />
      <Route path="/admin-redemptions" component={AdminRedemptionApproval} />
      <Route path="/admin-reports" component={AdminReports} />

      {/* Super Admin */}
      <Route path="/super-admin" component={SuperAdminPanel} />

      {/* Fallback */}
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
