import React, { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { LuxuryCard, LuxuryCardContent, LuxuryCardHeader, LuxuryCardTitle } from "@/components/LuxuryCard";
import { TierBadge } from "@/components/TierBadge";
import { trpc } from "@/lib/trpc";
import { LogOut, Gift, History, TrendingUp, TrendingDown } from "lucide-react";

export default function CustomerProfile() {
  const [, setLocation] = useLocation();
  const [customerId, setCustomerId] = useState<number | null>(null);

  useEffect(() => {
    const id = sessionStorage.getItem("customerId");
    if (!id) { setLocation("/login"); return; }
    setCustomerId(Number(id));
  }, []);

  const { data: profile, isLoading } = trpc.customer.getProfile.useQuery(
    { customerId: customerId || 0 },
    { enabled: !!customerId }
  );

  const { data: transactions } = trpc.customer.getPointHistory.useQuery(
    { customerId: customerId || 0, limit: 5 },
    { enabled: !!customerId }
  );

  const handleLogout = () => {
    sessionStorage.removeItem("customerId");
    sessionStorage.removeItem("customerName");
    setLocation("/");
  };

  if (isLoading || !profile) {
    return (
      <div className="art-deco-bg min-h-screen flex items-center justify-center">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 border-4 border-yellow-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-slate-600">กำลังโหลด...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="art-deco-bg min-h-screen p-4 pb-20">
      <div className="max-w-2xl mx-auto space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between pt-2">
          <div>
            <h1 className="text-3xl font-bold text-gradient">ยินดีต้อนรับ</h1>
            <p className="text-slate-600">{profile.name}</p>
          </div>
          <Button onClick={handleLogout} variant="outline" size="sm" className="gap-2 border-yellow-500/30">
            <LogOut size={16} />
            ออกจากระบบ
          </Button>
        </div>

        {/* Points Card */}
        <LuxuryCard className="p-8">
          <div className="space-y-6">
            <div className="text-center space-y-1">
              <p className="text-sm text-slate-500">แต้มสะสมทั้งหมด</p>
              <div className="text-6xl font-bold text-gradient">{profile.totalPoints.toLocaleString()}</div>
              <p className="text-xs text-slate-400">แต้ม</p>
            </div>

            <div className="art-deco-divider" />

            <div className="text-center">
              <p className="text-sm text-slate-500 mb-3">ระดับสมาชิก</p>
              <TierBadge tierName={profile.currentTier.name} currentPoints={profile.totalPoints} />
            </div>

            {profile.nextTier && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">ไปยัง {profile.nextTier.name}</span>
                  <span className="font-semibold text-yellow-700">{profile.progressToNextTier}%</span>
                </div>
                <div className="progress-art-deco" style={{ "--value": `${profile.progressToNextTier}%` } as React.CSSProperties} />
                <p className="text-xs text-slate-400 text-center">
                  ต้องการอีก {(profile.nextTier.minPoints - profile.totalPoints).toLocaleString()} แต้ม
                </p>
              </div>
            )}
          </div>
        </LuxuryCard>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-4">
          <Button className="btn-gold h-16 gap-2 text-base rounded-lg" onClick={() => setLocation("/rewards-shop")}>
            <Gift size={20} />
            แลกรางวัล
          </Button>
          <Button className="btn-gold h-16 gap-2 text-base rounded-lg" onClick={() => setLocation("/redemption-status")}>
            <History size={20} />
            ประวัติการแลก
          </Button>
        </div>

        {/* Recent Transactions */}
        {transactions && transactions.length > 0 && (
          <LuxuryCard>
            <LuxuryCardHeader>
              <LuxuryCardTitle>ประวัติแต้มล่าสุด</LuxuryCardTitle>
            </LuxuryCardHeader>
            <LuxuryCardContent>
              <div className="space-y-2">
                {transactions.map((tx) => (
                  <div key={tx.id} className="flex items-center justify-between p-3 rounded-lg bg-yellow-50/50 border border-yellow-500/10">
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${tx.points > 0 ? "bg-green-100" : "bg-red-100"}`}>
                        {tx.points > 0 ? <TrendingUp size={14} className="text-green-600" /> : <TrendingDown size={14} className="text-red-600" />}
                      </div>
                      <div>
                        <p className="font-medium text-sm">{tx.reason}</p>
                        <p className="text-xs text-slate-400">{new Date(tx.createdAt).toLocaleDateString("th-TH")}</p>
                      </div>
                    </div>
                    <div className={`font-bold text-lg ${tx.points > 0 ? "text-green-600" : "text-red-600"}`}>
                      {tx.points > 0 ? "+" : ""}{tx.points}
                    </div>
                  </div>
                ))}
              </div>
            </LuxuryCardContent>
          </LuxuryCard>
        )}
      </div>
    </div>
  );
}
