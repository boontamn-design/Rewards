import React, { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { OnScreenKeypad } from "@/components/OnScreenKeypad";
import { LuxuryCard, LuxuryCardContent, LuxuryCardHeader, LuxuryCardTitle } from "@/components/LuxuryCard";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ArrowLeft, ShieldCheck } from "lucide-react";

type Step = "phone" | "pin";

export default function AdminLogin() {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState<Step>("phone");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [pin, setPin] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const verifyPinMutation = trpc.admin.verifyPin.useMutation();

  const handlePhoneSubmit = () => {
    if (!phoneNumber.match(/^\d{10}$/)) {
      toast.error("กรุณากรอกเบอร์โทรศัพท์ 10 หลัก");
      return;
    }
    setStep("pin");
  };

  const handlePinSubmit = async () => {
    if (pin.length !== 6) {
      toast.error("กรุณากรอก PIN 6 หลัก");
      return;
    }
    setIsLoading(true);
    try {
      const result = await verifyPinMutation.mutateAsync({ phoneNumber, pin });
      toast.success(`ยินดีต้อนรับ ${result.name}`);
      sessionStorage.setItem("adminId", String(result.adminId));
      sessionStorage.setItem("adminName", result.name);
      sessionStorage.setItem("adminRole", result.role);
      if (result.role === "super_admin") {
        setLocation("/super-admin");
      } else {
        setLocation("/admin-dashboard");
      }
    } catch (error: any) {
      toast.error(error.message || "PIN ไม่ถูกต้อง");
      setPin("");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="art-deco-bg min-h-screen flex items-center justify-center p-4">
      <div className="max-w-md w-full space-y-6">
        <button
          onClick={() => { if (step === "phone") setLocation("/"); else { setStep("phone"); setPin(""); } }}
          className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors"
        >
          <ArrowLeft size={20} />
          กลับ
        </button>

        <div className="text-center space-y-2">
          <div className="flex justify-center mb-3">
            <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center">
              <ShieldCheck className="text-slate-700" size={32} />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gradient">Admin Login</h1>
          <p className="text-slate-600">เข้าสู่ระบบผู้ดูแล</p>
        </div>

        {step === "phone" && (
          <LuxuryCard>
            <LuxuryCardHeader>
              <LuxuryCardTitle>เบอร์โทรศัพท์</LuxuryCardTitle>
            </LuxuryCardHeader>
            <LuxuryCardContent>
              <Input
                type="tel"
                placeholder="0xxxxxxxxx"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, "").slice(0, 10))}
                maxLength={10}
                className="text-center text-xl tracking-widest"
              />
              <Button
                onClick={handlePhoneSubmit}
                disabled={phoneNumber.length !== 10}
                className="w-full btn-gold"
              >
                ต่อไป
              </Button>
            </LuxuryCardContent>
          </LuxuryCard>
        )}

        {step === "pin" && (
          <LuxuryCard>
            <LuxuryCardHeader>
              <LuxuryCardTitle>กรอก PIN</LuxuryCardTitle>
              <p className="text-sm text-slate-500 mt-1">{phoneNumber}</p>
            </LuxuryCardHeader>
            <LuxuryCardContent>
              <OnScreenKeypad value={pin} onChange={setPin} maxLength={6} disabled={isLoading} />
              <Button
                onClick={handlePinSubmit}
                disabled={isLoading || pin.length !== 6}
                className="w-full btn-gold"
              >
                {isLoading ? "กำลังเข้าสู่ระบบ..." : "เข้าสู่ระบบ"}
              </Button>
            </LuxuryCardContent>
          </LuxuryCard>
        )}

        <div className="text-center text-xs text-slate-400">
          <p>ทดสอบ: 0800000001 / PIN: 737570 (Super Admin)</p>
          <p>ทดสอบ: 0800000002 / PIN: 123456 (Admin)</p>
        </div>
      </div>
    </div>
  );
}
