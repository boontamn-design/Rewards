import React from "react";
import { useLocation } from "wouter";
import { Crown, User, ShieldCheck, ArrowLeft } from "lucide-react";
import { LuxuryCard } from "@/components/LuxuryCard";

export default function UnifiedLogin() {
  const [, setLocation] = useLocation();

  return (
    <div className="art-deco-bg min-h-screen flex items-center justify-center p-4">
      <div className="max-w-md w-full space-y-6">
        <button
          onClick={() => setLocation("/")}
          className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors"
        >
          <ArrowLeft size={20} />
          กลับหน้าหลัก
        </button>

        <div className="text-center space-y-2">
          <div className="flex justify-center mb-4">
            <Crown className="text-yellow-600" size={48} />
          </div>
          <h1 className="text-4xl font-bold text-gradient">เข้าสู่ระบบ</h1>
          <p className="text-slate-600">เลือกประเภทผู้ใช้งาน</p>
        </div>

        <div className="grid gap-4">
          <LuxuryCard
            className="cursor-pointer hover:border-yellow-500/60 transition-all"
            hover={true}
          >
            <button
              onClick={() => setLocation("/customer-login")}
              className="w-full flex items-center gap-4 text-left"
            >
              <div className="w-14 h-14 rounded-full bg-yellow-100 flex items-center justify-center flex-shrink-0">
                <User className="text-yellow-700" size={28} />
              </div>
              <div>
                <p className="font-bold text-lg">สมาชิก / ลูกค้า</p>
                <p className="text-sm text-slate-500">ดูแต้ม แลกรางวัล และประวัติการใช้งาน</p>
              </div>
            </button>
          </LuxuryCard>

          <LuxuryCard
            className="cursor-pointer hover:border-yellow-500/60 transition-all"
            hover={true}
          >
            <button
              onClick={() => setLocation("/admin-login")}
              className="w-full flex items-center gap-4 text-left"
            >
              <div className="w-14 h-14 rounded-full bg-slate-100 flex items-center justify-center flex-shrink-0">
                <ShieldCheck className="text-slate-700" size={28} />
              </div>
              <div>
                <p className="font-bold text-lg">ผู้ดูแลระบบ</p>
                <p className="text-sm text-slate-500">จัดการแต้ม อนุมัติการแลก และดูรายงาน</p>
              </div>
            </button>
          </LuxuryCard>
        </div>
      </div>
    </div>
  );
}
