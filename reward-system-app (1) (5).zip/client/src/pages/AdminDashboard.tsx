import React, { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { LuxuryCard, LuxuryCardContent, LuxuryCardHeader, LuxuryCardTitle } from "@/components/LuxuryCard";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { LogOut, Search, Plus, Minus, Users, Gift, TrendingUp, Clock, Shield, Upload, Download } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const [adminId, setAdminId] = useState<number | null>(null);
  const [adminName, setAdminName] = useState("");
  const [adminRole, setAdminRole] = useState("");
  const [searchPhone, setSearchPhone] = useState("");
  const [foundCustomer, setFoundCustomer] = useState<any>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [pointDialog, setPointDialog] = useState<"add" | "remove" | null>(null);
  const [pointAmount, setPointAmount] = useState("");
  const [pointReason, setPointReason] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [adminDialog, setAdminDialog] = useState(false);
  const [adminForm, setAdminForm] = useState({ phoneNumber: "", name: "", pin: "", role: "admin" as "admin" | "super_admin" });
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const [csvData, setCsvData] = useState<Array<{ phoneNumber: string; points: number; name?: string }>>([]);
  const [csvPreview, setCsvPreview] = useState<any[]>([]);
  const [csvDialog, setCsvDialog] = useState(false);
  const [isProcessingCsv, setIsProcessingCsv] = useState(false);

  useEffect(() => {
    const id = sessionStorage.getItem("adminId");
    const name = sessionStorage.getItem("adminName");
    const role = sessionStorage.getItem("adminRole");
    const sessionTime = sessionStorage.getItem("adminSessionTime");
    
    // Check session expiration (24 hours)
    if (sessionTime) {
      const elapsed = Date.now() - Number(sessionTime);
      const sessionExpiration = 24 * 60 * 60 * 1000;
      if (elapsed > sessionExpiration) {
        sessionStorage.clear();
        toast.error("Session หมดอายุ กรุณาเข้าสู่ระบบใหม่");
        setLocation("/");
        return;
      }
    }
    
    if (!id) { setLocation("/"); return; }
    setAdminId(Number(id));
    setAdminName(name || "");
    setAdminRole(role || "");
  }, []);

  const { data: stats } = trpc.admin.getStatistics.useQuery();
  const { data: pendingRedemptions } = trpc.admin.getPendingRedemptions.useQuery();

  const addPointsMutation = trpc.admin.addPoints.useMutation();
  const removePointsMutation = trpc.admin.removePoints.useMutation();
  const createAdminMutation = trpc.superAdmin.createAdmin.useMutation();
  const utils = trpc.useUtils();

  const handleSearchChange = async (phone: string) => {
    setSearchPhone(phone);
    if (!phone.trim()) {
      setSearchResults([]);
      setShowDropdown(false);
      return;
    }
    try {
      const result = await utils.admin.searchByPhone.fetch({ phoneNumber: phone });
      if (result) {
        setSearchResults([result]);
        setShowDropdown(true);
      } else {
        setSearchResults([]);
        setShowDropdown(false);
      }
    } catch (error: any) {
      setSearchResults([]);
      setShowDropdown(false);
    }
  };

  const handleSelectCustomer = (customer: any) => {
    setFoundCustomer(customer);
    setSearchPhone(customer.phoneNumber);
    setShowDropdown(false);
    setSearchResults([]);
  };

  const handlePointAction = async () => {
    if (!foundCustomer || !adminId || !pointAmount || !pointReason) {
      toast.error("กรุณากรอกข้อมูลให้ครบ");
      return;
    }
    const amount = parseInt(pointAmount);
    if (isNaN(amount) || amount <= 0) { toast.error("จำนวนแต้มต้องเป็นตัวเลขบวก"); return; }
    setIsSubmitting(true);
    try {
      if (pointDialog === "add") {
        await addPointsMutation.mutateAsync({ customerId: foundCustomer.id, points: amount, reason: pointReason, adminId, adminName });
        toast.success(`เพิ่ม ${amount} แต้มสำเร็จ`);
        setFoundCustomer({ ...foundCustomer, totalPoints: foundCustomer.totalPoints + amount });
      } else {
        await removePointsMutation.mutateAsync({ customerId: foundCustomer.id, points: amount, reason: pointReason, adminId, adminName });
        toast.success(`ลด ${amount} แต้มสำเร็จ`);
        setFoundCustomer({ ...foundCustomer, totalPoints: Math.max(0, foundCustomer.totalPoints - amount) });
      }
      setPointDialog(null);
      setPointAmount("");
      setPointReason("");
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาด");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCreateAdmin = async () => {
    if (!adminForm.phoneNumber || !adminForm.name || !adminForm.pin) { toast.error("กรุณากรอกข้อมูลให้ครบ"); return; }
    if (adminForm.pin.length !== 6) { toast.error("PIN ต้องมี 6 หลัก"); return; }
    setIsSubmitting(true);
    try {
      await createAdminMutation.mutateAsync(adminForm);
      toast.success("สร้าง Admin สำเร็จ");
      setAdminDialog(false);
      setAdminForm({ phoneNumber: "", name: "", pin: "", role: "admin" });
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาด");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem("adminId");
    sessionStorage.removeItem("adminName");
    sessionStorage.removeItem("adminRole");
    sessionStorage.removeItem("adminSessionTime");
    setLocation("/");
  };

  const handleCsvUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const csv = event.target?.result as string;
        const lines = csv.split('\n').filter(l => l.trim());
        const data = [];

        for (let i = 1; i < lines.length; i++) {
          const [phoneNumber, pointsStr] = lines[i].split(',').map(s => s.trim());
          if (!phoneNumber || !pointsStr) continue;

          const points = parseInt(pointsStr);
          if (isNaN(points)) continue;

          data.push({ phoneNumber, points });
        }

        setCsvData(data);

        // Search for customer names
        setIsProcessingCsv(true);
        const preview = [];
        for (const row of data) {
          try {
            const result = await utils.admin.searchByPhone.fetch({ phoneNumber: row.phoneNumber });
            preview.push({ ...row, name: result?.name || 'ไม่พบ', customerId: result?.id });
          } catch {
            preview.push({ ...row, name: 'ไม่พบ', customerId: null });
          }
        }
        setCsvPreview(preview);
        setCsvDialog(true);
        setIsProcessingCsv(false);
      } catch (error) {
        toast.error('ไฟล์ CSV ไม่ถูกต้อง');
      }
    };
    reader.readAsText(file);
  };

  const handleConfirmCsv = async () => {
    setIsProcessingCsv(true);
    try {
      let successCount = 0;
      for (const row of csvPreview) {
        if (row.customerId) {
          await addPointsMutation.mutateAsync({
            customerId: row.customerId,
            points: row.points,
            reason: 'CSV Import',
            adminId: adminId!,
            adminName
          });
          successCount++;
        }
      }
      toast.success(`อัพเดทแต้มสำเร็จ ${successCount} รายการ`);
      setCsvDialog(false);
      setCsvData([]);
      setCsvPreview([]);
    } catch (error) {
      toast.error('เกิดข้อผิดพลาดในการอัพเดท');
    } finally {
      setIsProcessingCsv(false);
    }
  };

  const handleDownloadTemplate = () => {
    const templateData = `phoneNumber,points
0812345678,500
0898765432,1000
0811111111,750`;

    const blob = new Blob([templateData], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', 'csv-template.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="art-deco-bg min-h-screen p-4 pb-20">
      <div className="max-w-3xl mx-auto space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between pt-2">
          <div>
            <h1 className="text-3xl font-bold text-gradient">Admin Dashboard</h1>
            <p className="text-slate-500 text-sm">{adminName} · {adminRole === "super_admin" ? "Super Admin" : "Admin"}</p>
          </div>
          <div className="flex gap-2">
            {adminRole === "super_admin" && (
              <Button onClick={() => setLocation("/super-admin")} variant="outline" size="sm" className="border-yellow-500/30 text-yellow-700">
                Super Admin
              </Button>
            )}
            <Button onClick={() => setLocation("/admin-redemptions")} variant="outline" size="sm" className="border-yellow-500/30">
              อนุมัติการแลก
            </Button>
            <Button onClick={() => setLocation("/admin-reports")} variant="outline" size="sm" className="border-yellow-500/30">
              รายงาน
            </Button>
            <Button onClick={() => setAdminDialog(true)} className="btn-gold gap-1 text-sm">
              <Plus size={14} /> เพิ่มแอดมิน
            </Button>
            <Button onClick={handleDownloadTemplate} variant="outline" size="sm" className="gap-1 border-yellow-500/30">
              <Download size={14} /> ดาวน์โหลด Template
            </Button>
            <label className="cursor-pointer">
              <input type="file" accept=".csv" onChange={handleCsvUpload} className="hidden" id="csv-upload" />
              <Button variant="outline" size="sm" className="gap-1 border-yellow-500/30 cursor-pointer" onClick={() => document.getElementById('csv-upload')?.click()}>
                <Upload size={14} /> นำเข้า CSV
              </Button>
            </label>
            <Button onClick={handleLogout} variant="outline" size="sm" className="gap-1">
              <LogOut size={14} />
            </Button>
          </div>
        </div>

        {/* Stats */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { icon: <Users size={20} className="text-yellow-600" />, label: "ลูกค้าทั้งหมด", value: stats.totalCustomers },
              { icon: <TrendingUp size={20} className="text-green-600" />, label: "แต้มที่แจก", value: stats.totalPointsDistributed.toLocaleString() },
              { icon: <Gift size={20} className="text-blue-600" />, label: "แต้มที่แลก", value: stats.totalPointsRedeemed.toLocaleString() },
              { icon: <Clock size={20} className="text-orange-600" />, label: "รอการอนุมัติ", value: stats.pendingRedemptions },
            ].map((s) => (
              <LuxuryCard key={s.label} className="p-4">
                <div className="flex items-center gap-2 mb-1">{s.icon}<p className="text-xs text-slate-500">{s.label}</p></div>
                <p className="text-2xl font-bold">{s.value}</p>
              </LuxuryCard>
            ))}
          </div>
        )}

        {/* Tabs */}
        <Tabs defaultValue="points">
          <TabsList className="w-full">
            <TabsTrigger value="points" className="flex-1 gap-2"><TrendingUp size={14} />ปรับคะแนน</TabsTrigger>
            <TabsTrigger value="rewards" className="flex-1 gap-2"><Gift size={14} />ปรับรางวัล</TabsTrigger>
            <TabsTrigger value="tier" className="flex-1 gap-2"><Users size={14} />ปรับระดับลูกค้า</TabsTrigger>
          </TabsList>

          {/* Tab 1: Points */}
          <TabsContent value="points" className="space-y-4 mt-4">
            <LuxuryCard>
              <LuxuryCardHeader>
                <LuxuryCardTitle>ค้นหาลูกค้า</LuxuryCardTitle>
              </LuxuryCardHeader>
              <LuxuryCardContent>
                <div className="flex gap-2 relative">
                  <div className="flex-1 relative">
                    <Input
                      placeholder="เบอร์โทรศัพท์"
                      value={searchPhone}
                      onChange={(e) => handleSearchChange(e.target.value.replace(/\D/g, "").slice(0, 10))}
                      onFocus={() => searchPhone && setShowDropdown(true)}
                      className="flex-1"
                    />
                    {showDropdown && searchResults.length > 0 && (
                      <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-yellow-500/30 rounded-lg shadow-lg z-50">
                        {searchResults.map((customer) => (
                          <button
                            key={customer.id}
                            onClick={() => handleSelectCustomer(customer)}
                            className="w-full px-3 py-2 text-left hover:bg-yellow-50/50 border-b border-yellow-500/10 last:border-b-0 transition-colors"
                          >
                            <p className="font-medium text-sm">{customer.name}</p>
                            <p className="text-xs text-slate-500">{customer.phoneNumber} · {customer.totalPoints.toLocaleString()} แต้ม</p>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {foundCustomer && (
                  <div className="mt-4 p-4 rounded-lg bg-yellow-50/50 border border-yellow-500/20 space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="font-bold text-lg">{foundCustomer.name}</p>
                        <p className="text-sm text-slate-500">{foundCustomer.phoneNumber}</p>
                        {foundCustomer.email && <p className="text-xs text-slate-400">{foundCustomer.email}</p>}
                      </div>
                      <div className="text-right">
                        <p className="text-3xl font-bold text-gradient">{foundCustomer.totalPoints.toLocaleString()}</p>
                        <p className="text-xs text-slate-500">แต้ม</p>
                      </div>
                    </div>
                    <Button onClick={() => { setFoundCustomer(null); setSearchPhone(""); setSearchResults([]); }} variant="outline" size="sm" className="w-full text-slate-500">
                      ค้นหาลูกค้าคนอื่น
                    </Button>
                    <div className="flex gap-2">
                      <Button onClick={() => setPointDialog("add")} className="flex-1 btn-gold gap-2">
                        <Plus size={16} />
                        เพิ่มแต้ม
                      </Button>
                      <Button onClick={() => setPointDialog("remove")} variant="outline" className="flex-1 gap-2 border-red-300 text-red-600 hover:bg-red-50">
                        <Minus size={16} />
                        ลดแต้ม
                      </Button>
                    </div>
                  </div>
                )}
              </LuxuryCardContent>
            </LuxuryCard>
          </TabsContent>

          {/* Tab 2: Rewards */}
          <TabsContent value="rewards" className="space-y-4 mt-4">
            <LuxuryCard>
              <LuxuryCardHeader>
                <LuxuryCardTitle>ปรับรางวัล</LuxuryCardTitle>
              </LuxuryCardHeader>
              <LuxuryCardContent>
                <p className="text-slate-500 text-sm">ฟีเจอร์นี้อยู่ใน Super Admin Panel</p>
                <Button onClick={() => setLocation("/super-admin")} className="mt-3 btn-gold w-full">
                  ไปที่ Super Admin
                </Button>
              </LuxuryCardContent>
            </LuxuryCard>
          </TabsContent>

          {/* Tab 3: Tier */}
          <TabsContent value="tier" className="space-y-4 mt-4">
            <LuxuryCard>
              <LuxuryCardHeader>
                <LuxuryCardTitle>ปรับระดับลูกค้า</LuxuryCardTitle>
              </LuxuryCardHeader>
              <LuxuryCardContent>
                <p className="text-slate-500 text-sm">ฟีเจอร์นี้อยู่ใน Super Admin Panel</p>
                <Button onClick={() => setLocation("/super-admin")} className="mt-3 btn-gold w-full">
                  ไปที่ Super Admin
                </Button>
              </LuxuryCardContent>
            </LuxuryCard>
          </TabsContent>
        </Tabs>

        {/* Pending Redemptions Preview */}
        {pendingRedemptions && pendingRedemptions.length > 0 && (
          <LuxuryCard>
            <LuxuryCardHeader>
              <div className="flex items-center justify-between">
                <LuxuryCardTitle>รอการอนุมัติ ({pendingRedemptions.length})</LuxuryCardTitle>
                <Button onClick={() => setLocation("/admin-redemptions")} variant="outline" size="sm" className="border-yellow-500/30 text-yellow-700">
                  ดูทั้งหมด
                </Button>
              </div>
            </LuxuryCardHeader>
            <LuxuryCardContent>
              <div className="space-y-2">
                {pendingRedemptions.slice(0, 3).map((r) => (
                  <div key={r.id} className="flex items-center justify-between p-3 rounded-lg bg-orange-50/50 border border-orange-200">
                    <div>
                      <p className="font-medium text-sm">{r.customerName}</p>
                      <p className="text-xs text-slate-500">{r.rewardName} · {r.pointsUsed.toLocaleString()} แต้ม</p>
                    </div>
                    <span className="status-badge status-pending">รอ</span>
                  </div>
                ))}
              </div>
            </LuxuryCardContent>
          </LuxuryCard>
        )}
      </div>

      {/* Point Dialog */}
      <Dialog open={!!pointDialog} onOpenChange={() => { setPointDialog(null); setPointAmount(""); setPointReason(""); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{pointDialog === "add" ? "เพิ่มแต้ม" : "ลดแต้ม"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              type="number"
              placeholder="จำนวนแต้ม"
              value={pointAmount}
              onChange={(e) => setPointAmount(e.target.value)}
              disabled={isSubmitting}
            />
            <Input
              placeholder="เหตุผล"
              value={pointReason}
              onChange={(e) => setPointReason(e.target.value)}
              disabled={isSubmitting}
            />
          </div>
          <DialogFooter>
            <Button onClick={handlePointAction} disabled={isSubmitting} className="btn-gold">
              {isSubmitting ? "กำลังบันทึก..." : "ยืนยัน"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Admin Dialog */}
      <Dialog open={adminDialog} onOpenChange={setAdminDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>เพิ่ม Admin</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              placeholder="เบอร์โทร"
              value={adminForm.phoneNumber}
              onChange={(e) => setAdminForm({ ...adminForm, phoneNumber: e.target.value.replace(/\D/g, "").slice(0, 10) })}
              disabled={isSubmitting}
            />
            <Input
              placeholder="ชื่อ"
              value={adminForm.name}
              onChange={(e) => setAdminForm({ ...adminForm, name: e.target.value })}
              disabled={isSubmitting}
            />
            <Input
              placeholder="PIN 6 หลัก"
              value={adminForm.pin}
              onChange={(e) => setAdminForm({ ...adminForm, pin: e.target.value.replace(/\D/g, "").slice(0, 6) })}
              disabled={isSubmitting}
            />
            <select
              value={adminForm.role}
              onChange={(e) => setAdminForm({ ...adminForm, role: e.target.value as "admin" | "super_admin" })}
              disabled={isSubmitting}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg"
            >
              <option value="admin">Admin</option>
              <option value="super_admin">Super Admin</option>
            </select>
          </div>
          <DialogFooter>
            <Button onClick={handleCreateAdmin} disabled={isSubmitting} className="btn-gold">
              {isSubmitting ? "กำลังสร้าง..." : "สร้าง"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* CSV Preview Dialog */}
      <Dialog open={csvDialog} onOpenChange={setCsvDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>ตรวจสอบข้อมูล CSV</DialogTitle>
          </DialogHeader>
          {isProcessingCsv ? (
            <p className="text-center text-slate-500">กำลังค้นหาข้อมูลลูกค้า...</p>
          ) : (
            <div className="max-h-96 overflow-y-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-yellow-500/30">
                    <th className="text-left p-2">เบอร์โทร</th>
                    <th className="text-left p-2">ชื่อ</th>
                    <th className="text-right p-2">แต้ม</th>
                  </tr>
                </thead>
                <tbody>
                  {csvPreview.map((row, idx) => (
                    <tr key={idx} className={`border-b border-yellow-500/10 ${row.customerId ? "" : "opacity-50"}`}>
                      <td className="p-2">{row.phoneNumber}</td>
                      <td className="p-2">{row.name}</td>
                      <td className="text-right p-2">{row.points.toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <DialogFooter>
            <Button onClick={() => setCsvDialog(false)} variant="outline" disabled={isProcessingCsv}>
              ยกเลิก
            </Button>
            <Button onClick={handleConfirmCsv} disabled={isProcessingCsv} className="btn-gold">
              {isProcessingCsv ? "กำลังอัพเดท..." : "ยืนยันและอัพเดท"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
