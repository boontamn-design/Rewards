import React, { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { LuxuryCard, LuxuryCardContent, LuxuryCardHeader, LuxuryCardTitle } from "@/components/LuxuryCard";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ArrowLeft, CheckCircle, XCircle, Clock, Gift, Filter } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";

type FilterType = "all" | "pending" | "approved" | "rejected";

export default function AdminRedemptionApproval() {
  const [, setLocation] = useLocation();
  const [adminId, setAdminId] = useState<number | null>(null);
  const [adminName, setAdminName] = useState("");
  const [filter, setFilter] = useState<FilterType>("pending");
  const [rejectDialog, setRejectDialog] = useState<number | null>(null);
  const [rejectReason, setRejectReason] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const id = sessionStorage.getItem("adminId");
    const name = sessionStorage.getItem("adminName");
    if (!id) { setLocation("/admin-login"); return; }
    setAdminId(Number(id));
    setAdminName(name || "");
  }, []);

  const { data: pendingRedemptions, refetch: refetchPending } = trpc.admin.getPendingRedemptions.useQuery();
  const { data: allRedemptions, refetch: refetchAll } = trpc.admin.getAllRedemptions.useQuery();

  const approveMutation = trpc.admin.approveRedemption.useMutation();
  const rejectMutation = trpc.admin.rejectRedemption.useMutation();

  const handleApprove = async (redemptionId: number) => {
    if (!adminId) return;
    setIsSubmitting(true);
    try {
      await approveMutation.mutateAsync({ redemptionId, adminId, adminName });
      toast.success("อนุมัติการแลกรางวัลสำเร็จ");
      refetchPending();
      refetchAll();
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาด");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReject = async () => {
    if (!rejectDialog || !rejectReason.trim()) { toast.error("กรุณากรอกเหตุผล"); return; }
    setIsSubmitting(true);
    try {
      await rejectMutation.mutateAsync({ redemptionId: rejectDialog, rejectionReason: rejectReason });
      toast.success("ปฏิเสธการแลกรางวัลแล้ว");
      setRejectDialog(null);
      setRejectReason("");
      refetchPending();
      refetchAll();
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาด");
    } finally {
      setIsSubmitting(false);
    }
  };

  const displayList = filter === "pending" ? pendingRedemptions : allRedemptions?.filter(r => filter === "all" || r.status === filter);

  const statusConfig: Record<string, { label: string; className: string }> = {
    pending: { label: "รอการอนุมัติ", className: "status-badge status-pending" },
    approved: { label: "อนุมัติแล้ว", className: "status-badge status-approved" },
    rejected: { label: "ปฏิเสธ", className: "status-badge status-rejected" },
    completed: { label: "เสร็จสิ้น", className: "status-badge status-completed" },
  };

  return (
    <div className="art-deco-bg min-h-screen p-4 pb-20">
      <div className="max-w-3xl mx-auto space-y-5">
        <div className="flex items-center gap-3 pt-2">
          <button onClick={() => setLocation("/admin-dashboard")} className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors">
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-3xl font-bold text-gradient">อนุมัติการแลกรางวัล</h1>
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-1">
          {(["pending", "all", "approved", "rejected"] as FilterType[]).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                filter === f
                  ? "bg-yellow-500 text-black"
                  : "bg-white border border-yellow-500/30 text-slate-600 hover:border-yellow-500/60"
              }`}
            >
              {f === "pending" ? "รอการอนุมัติ" : f === "all" ? "ทั้งหมด" : f === "approved" ? "อนุมัติแล้ว" : "ปฏิเสธ"}
            </button>
          ))}
        </div>

        {!displayList ? (
          <div className="text-center py-12">
            <div className="w-12 h-12 border-4 border-yellow-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
            <p className="text-slate-500">กำลังโหลด...</p>
          </div>
        ) : displayList.length === 0 ? (
          <LuxuryCard className="text-center py-12">
            <Gift size={48} className="text-yellow-500/40 mx-auto mb-3" />
            <p className="text-slate-500">ไม่มีรายการ</p>
          </LuxuryCard>
        ) : (
          <div className="space-y-4">
            {displayList.map((r) => {
              const status = statusConfig[r.status] || statusConfig.pending;
              return (
                <LuxuryCard key={r.id}>
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="font-bold">{r.customerName}</p>
                        <p className="text-sm text-slate-500">{r.customerPhone}</p>
                      </div>
                      <span className={status.className}>{status.label}</span>
                    </div>
                    <div className="flex items-center gap-2 p-2 rounded-lg bg-yellow-50/50 border border-yellow-500/10">
                      <Gift size={16} className="text-yellow-600" />
                      <div>
                        <p className="font-medium text-sm">{r.rewardName}</p>
                        <p className="text-xs text-slate-500">{r.pointsUsed.toLocaleString()} แต้ม</p>
                      </div>
                    </div>
                    <p className="text-xs text-slate-400">
                      {new Date(r.createdAt).toLocaleDateString("th-TH", { year: "numeric", month: "long", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                    </p>
                    {r.status === "rejected" && r.rejectionReason && (
                      <p className="text-xs text-red-500">เหตุผล: {r.rejectionReason}</p>
                    )}
                    {r.status === "pending" && (
                      <div className="flex gap-2 pt-1">
                        <Button
                          onClick={() => handleApprove(r.id)}
                          disabled={isSubmitting}
                          className="flex-1 btn-gold gap-2"
                          size="sm"
                        >
                          <CheckCircle size={14} />
                          อนุมัติ
                        </Button>
                        <Button
                          onClick={() => setRejectDialog(r.id)}
                          disabled={isSubmitting}
                          variant="outline"
                          className="flex-1 gap-2 border-red-300 text-red-600 hover:bg-red-50"
                          size="sm"
                        >
                          <XCircle size={14} />
                          ปฏิเสธ
                        </Button>
                      </div>
                    )}
                  </div>
                </LuxuryCard>
              );
            })}
          </div>
        )}
      </div>

      <Dialog open={!!rejectDialog} onOpenChange={() => { setRejectDialog(null); setRejectReason(""); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>ปฏิเสธการแลกรางวัล</DialogTitle>
          </DialogHeader>
          <div className="py-2">
            <label className="text-sm font-medium">เหตุผลการปฏิเสธ</label>
            <Input
              placeholder="กรุณากรอกเหตุผล"
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              className="mt-1"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRejectDialog(null)}>ยกเลิก</Button>
            <Button onClick={handleReject} disabled={isSubmitting || !rejectReason} className="bg-red-600 text-white hover:bg-red-700">
              {isSubmitting ? "กำลังดำเนินการ..." : "ยืนยันการปฏิเสธ"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
