import React, { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { OnScreenKeypad } from "@/components/OnScreenKeypad";
import { LuxuryCard, LuxuryCardContent, LuxuryCardHeader, LuxuryCardTitle } from "@/components/LuxuryCard";
import { Crown, Star, Gift, Users, LogOut } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

type LoginStep = "phone" | "pin" | "register" | "none";

export default function Home() {
  const [, setLocation] = useLocation();
  const [loginStep, setLoginStep] = useState<LoginStep>("none");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [pin, setPin] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const verifyPinMutation = trpc.customer.verifyPin.useMutation();
  const createCustomerMutation = trpc.customer.create.useMutation();
  const adminVerifyPinMutation = trpc.admin.verifyPin.useMutation();
  const utils = trpc.useUtils();

  const handlePhoneSubmit = async () => {
    if (!phoneNumber.match(/^\d{10}$/)) {
      toast.error("กรุณากรอกเบอร์โทรศัพท์ 10 หลัก");
      return;
    }
    setIsLoading(true);
    try {
      // ตรวจสอบว่าเป็น admin ก่อน
      const adminResult = await utils.admin.checkExists.fetch({ phoneNumber });
      if (adminResult.exists) {
        setLoginStep("pin");
        return;
      }

      // ตรวจสอบว่าเป็นลูกค้าหรือไม่
      const customerResult = await utils.customer.checkExists.fetch({ phoneNumber });
      if (customerResult.exists) {
        setLoginStep("pin");
      } else {
        setLoginStep("register");
      }
    } catch (error) {
      toast.error("เกิดข้อผิดพลาด กรุณาลองใหม่");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePinSubmit = async (pinValue: string) => {
    if (pinValue.length !== 6) return;
    setIsLoading(true);
    try {
      // ลองเป็น admin ก่อน
      try {
        const result = await adminVerifyPinMutation.mutateAsync({ phoneNumber, pin: pinValue });
        toast.success(`ยินดีต้อนรับ ${result.name}`);
        sessionStorage.setItem("adminId", String(result.adminId));
        sessionStorage.setItem("adminName", result.name);
        sessionStorage.setItem("adminRole", result.role);
        sessionStorage.setItem("adminSessionTime", String(Date.now()));
        if (result.role === "super_admin") {
          setLocation("/super-admin");
        } else {
          setLocation("/admin-dashboard");
        }
        return;
      } catch {
        // ไม่ใช่ admin ให้ลองเป็นลูกค้า
      }

      // ลองเป็นลูกค้า
      const result = await verifyPinMutation.mutateAsync({ phoneNumber, pin: pinValue });
      toast.success(`ยินดีต้อนรับ ${result.name}`);
      sessionStorage.setItem("customerId", String(result.customerId));
      sessionStorage.setItem("customerName", result.name);
      setLocation("/customer-profile");
    } catch (error: any) {
      toast.error(error.message || "PIN ไม่ถูกต้อง");
      setPin("");
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = async () => {
    if (!name.trim()) { toast.error("กรุณากรอกชื่อ"); return; }
    if (pin.length !== 6) { toast.error("กรุณากรอก PIN 6 หลัก"); return; }
    setIsLoading(true);
    try {
      const result = await createCustomerMutation.mutateAsync({ phoneNumber, name, email: email || undefined, pin });
      toast.success("สมัครสมาชิกสำเร็จ!");
      sessionStorage.setItem("customerId", String(result?.id));
      sessionStorage.setItem("customerName", name);
      setLocation("/customer-profile");
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาด");
    } finally {
      setIsLoading(false);
    }
  };

  const resetLogin = () => {
    setLoginStep("none");
    setPhoneNumber("");
    setPin("");
    setName("");
    setEmail("");
  };

  return (
    <div className="art-deco-bg min-h-screen">
      {/* Header */}
      <header className="border-b border-yellow-500/20 bg-white/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Crown className="text-yellow-600" size={28} />
            <div>
              <h1 className="text-xl font-bold text-gradient leading-none">LOYALTY</h1>
              <p className="text-xs text-slate-500 tracking-widest uppercase">Rewards Program</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-5xl mx-auto px-4 py-8">
        {loginStep === "none" ? (
          <>
            {/* Hero */}
            <section className="py-16 text-center">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-yellow-500/30 bg-yellow-50 text-yellow-700 text-sm font-medium mb-6">
                <Star size={14} />
                ระบบสะสมแต้มและแลกรางวัล
              </div>
              <h2 className="text-5xl font-bold text-gradient mb-4">สะสมแต้ม<br />แลกรางวัลพิเศษ</h2>
              <p className="text-slate-600 text-lg mb-8 max-w-xl mx-auto">
                สมัครสมาชิกและเริ่มสะสมแต้มได้เลย รับสิทธิพิเศษมากมายตามระดับสมาชิกของคุณ
              </p>
            </section>

            {/* Login Form */}
            <section className="max-w-md mx-auto mb-16">
              <LuxuryCard>
                <LuxuryCardHeader>
                  <LuxuryCardTitle>เข้าสู่ระบบ / สมัครสมาชิก</LuxuryCardTitle>
                </LuxuryCardHeader>
                <LuxuryCardContent>
                  <Input
                    type="tel"
                    placeholder="0xxxxxxxxx"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, "").slice(0, 10))}
                    maxLength={10}
                    disabled={isLoading}
                    className="text-center text-xl tracking-widest"
                  />
                  <Button
                    onClick={handlePhoneSubmit}
                    disabled={isLoading || phoneNumber.length !== 10}
                    className="w-full btn-gold"
                  >
                    {isLoading ? "กำลังตรวจสอบ..." : "ต่อไป"}
                  </Button>
                </LuxuryCardContent>
              </LuxuryCard>
            </section>

            {/* Tiers */}
            <section className="py-8">
              <h3 className="text-center text-2xl font-bold text-gradient mb-8">ระดับสมาชิก</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { name: "Bronze", points: "0+", color: "from-amber-700/20 to-amber-600/10", border: "border-amber-600/30", text: "text-amber-700" },
                  { name: "Silver", points: "1,000+", color: "from-slate-400/20 to-slate-300/10", border: "border-slate-400/30", text: "text-slate-600" },
                  { name: "Gold", points: "5,000+", color: "from-yellow-500/20 to-yellow-400/10", border: "border-yellow-500/30", text: "text-yellow-700" },
                  { name: "Platinum", points: "20,000+", color: "from-slate-300/30 to-slate-200/20", border: "border-slate-300/50", text: "text-slate-500" },
                ].map((tier) => (
                  <div key={tier.name} className={`luxury-card p-5 text-center bg-gradient-to-br ${tier.color} border ${tier.border}`}>
                    <Crown className={`mx-auto mb-2 ${tier.text}`} size={24} />
                    <p className={`font-bold text-lg ${tier.text}`}>{tier.name}</p>
                    <p className="text-xs text-slate-500 mt-1">{tier.points} แต้ม</p>
                  </div>
                ))}
              </div>
            </section>

            {/* Features */}
            <section className="py-8 pb-16">
              <div className="grid md:grid-cols-3 gap-6">
                {[
                  { icon: <Star className="text-yellow-600" size={28} />, title: "สะสมแต้มง่าย", desc: "รับแต้มทุกครั้งที่ซื้อสินค้าหรือบริการ" },
                  { icon: <Gift className="text-yellow-600" size={28} />, title: "แลกรางวัลหลากหลาย", desc: "เลือกแลกรางวัลที่ต้องการจากคลังรางวัลมากมาย" },
                  { icon: <Users className="text-yellow-600" size={28} />, title: "สิทธิพิเศษตามระดับ", desc: "ยิ่งสะสมมาก ยิ่งได้รับสิทธิพิเศษมากขึ้น" },
                ].map((f) => (
                  <div key={f.title} className="luxury-card p-6 text-center">
                    <div className="flex justify-center mb-3">{f.icon}</div>
                    <h4 className="font-bold text-lg mb-2">{f.title}</h4>
                    <p className="text-slate-600 text-sm">{f.desc}</p>
                  </div>
                ))}
              </div>
            </section>
          </>
        ) : (
          <>
            {/* Login Steps */}
            <section className="max-w-md mx-auto py-16">
              <button
                onClick={resetLogin}
                className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors mb-6"
              >
                <LogOut size={20} />
                กลับ
              </button>

              {loginStep === "pin" && (
                <LuxuryCard>
                  <LuxuryCardHeader>
                    <LuxuryCardTitle>กรอก PIN</LuxuryCardTitle>
                    <p className="text-sm text-slate-500 mt-1">{phoneNumber}</p>
                  </LuxuryCardHeader>
                  <LuxuryCardContent>
                    <OnScreenKeypad
                      value={pin}
                      onChange={(newPin) => {
                        setPin(newPin);
                        if (newPin.length === 6 && !isLoading) {
                          handlePinSubmit(newPin);
                        }
                      }}
                      maxLength={6}
                      disabled={isLoading}
                    />
                    {isLoading && <p className="text-center text-sm text-slate-500 mt-4">กำลังเข้าสู่ระบบ...</p>}
                  </LuxuryCardContent>
                </LuxuryCard>
              )}

              {loginStep === "register" && (
                <LuxuryCard>
                  <LuxuryCardHeader>
                    <LuxuryCardTitle>สมัครสมาชิก</LuxuryCardTitle>
                    <p className="text-sm text-slate-500 mt-1">{phoneNumber}</p>
                  </LuxuryCardHeader>
                  <LuxuryCardContent>
                    <Input
                      placeholder="ชื่อ-นามสกุล *"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      disabled={isLoading}
                    />
                    <Input
                      type="email"
                      placeholder="อีเมล (ไม่บังคับ)"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      disabled={isLoading}
                    />
                    <div>
                      <p className="text-sm font-medium text-slate-700 mb-2 text-center">ตั้ง PIN 6 หลัก</p>
                      <OnScreenKeypad value={pin} onChange={setPin} maxLength={6} disabled={isLoading} />
                    </div>
                    <Button
                      onClick={handleRegister}
                      disabled={isLoading || !name || pin.length !== 6}
                      className="w-full btn-gold"
                    >
                      {isLoading ? "กำลังสมัคร..." : "สมัครสมาชิก"}
                    </Button>
                  </LuxuryCardContent>
                </LuxuryCard>
              )}
            </section>
          </>
        )}
      </div>

      {/* Footer */}
      <footer className="border-t border-yellow-500/20 py-6 text-center text-slate-500 text-sm">
        <p>© 2025 Loyalty Rewards Program. All rights reserved.</p>
      </footer>
    </div>
  );
}
