import React, { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { LuxuryCard, LuxuryCardContent, LuxuryCardHeader, LuxuryCardTitle } from "@/components/LuxuryCard";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Gift, Clock, CheckCircle, XCircle } from "lucide-react";

const statusConfig: Record<string, { label: string; icon: React.ReactNode; className: string }> = {
  pending: { label: "รอการอนุมัติ", icon: <Clock size={14} />, className: "status-badge status-pending" },
  approved: { label: "อนุมัติแล้ว", icon: <CheckCircle size={14} />, className: "status-badge status-approved" },
  rejected: { label: "ปฏิเสธ", icon: <XCircle size={14} />, className: "status-badge status-rejected" },
  completed: { label: "เสร็จสิ้น", icon: <CheckCircle size={14} />, className: "status-badge status-completed" },
};

export default function RedemptionStatus() {
  const [, setLocation] = useLocation();
  const [customerId, setCustomerId] = useState<number | null>(null);

  useEffect(() => {
    const id = sessionStorage.getItem("customerId");
    if (!id) { setLocation("/login"); return; }
    setCustomerId(Number(id));
  }, []);

  const { data: redemptions, isLoading } = trpc.customer.getRedemptionHistory.useQuery(
    { customerId: customerId || 0 },
    { enabled: !!customerId }
  );

  return (
    <div className="art-deco-bg min-h-screen p-4 pb-20">
      <div className="max-w-2xl mx-auto space-y-5">
        <div className="flex items-center gap-3 pt-2">
          <button onClick={() => setLocation("/customer-profile")} className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors">
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-3xl font-bold text-gradient">ประวัติการแลกรางวัล</h1>
        </div>

        {isLoading ? (
          <div className="text-center py-12">
            <div className="w-12 h-12 border-4 border-yellow-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
            <p className="text-slate-500">กำลังโหลด...</p>
          </div>
        ) : !redemptions || redemptions.length === 0 ? (
          <LuxuryCard className="text-center py-12">
            <Gift size={48} className="text-yellow-500/40 mx-auto mb-3" />
            <p className="text-slate-500">ยังไม่มีประวัติการแลกรางวัล</p>
          </LuxuryCard>
        ) : (
          <div className="space-y-4">
            {redemptions.map((r) => {
              const status = statusConfig[r.status] || statusConfig.pending;
              return (
                <LuxuryCard key={r.id}>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-full bg-yellow-100 flex items-center justify-center flex-shrink-0">
                        <Gift size={18} className="text-yellow-700" />
                      </div>
                      <div>
                        <p className="font-bold">{r.rewardName}</p>
                        <p className="text-sm text-slate-500 mt-1">
                          ใช้ <span className="font-semibold text-yellow-700">{r.pointsUsed.toLocaleString()}</span> แต้ม
                        </p>
                        <p className="text-xs text-slate-400 mt-1">
                          {new Date(r.createdAt).toLocaleDateString("th-TH", { year: "numeric", month: "long", day: "numeric" })}
                        </p>
                        {r.status === "rejected" && r.rejectionReason && (
                          <p className="text-xs text-red-500 mt-1">เหตุผล: {r.rejectionReason}</p>
                        )}
                      </div>
                    </div>
                    <div className={status.className}>
                      {status.icon}
                      {status.label}
                    </div>
                  </div>
                </LuxuryCard>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
