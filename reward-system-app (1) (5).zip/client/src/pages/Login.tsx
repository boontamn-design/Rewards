import React, { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { OnScreenKeypad } from "@/components/OnScreenKeypad";
import { LuxuryCard, LuxuryCardContent, LuxuryCardHeader, LuxuryCardTitle } from "@/components/LuxuryCard";
import { Crown, LogOut, User, ShieldCheck } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

type LoginStep = "type" | "phone" | "pin" | "register" | "admin-pin";
type UserType = "customer" | "admin";

export default function Login() {
  const [, setLocation] = useLocation();
  const [loginStep, setLoginStep] = useState<LoginStep>("type");
  const [userType, setUserType] = useState<UserType | null>(null);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [pin, setPin] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const verifyPinMutation = trpc.customer.verifyPin.useMutation();
  const createCustomerMutation = trpc.customer.create.useMutation();
  const adminVerifyPinMutation = trpc.admin.verifyPin.useMutation();
  const utils = trpc.useUtils();

  const handleCustomerPhoneSubmit = async () => {
    if (!phoneNumber.match(/^\d{10}$/)) {
      toast.error("กรุณากรอกเบอร์โทรศัพท์ 10 หลัก");
      return;
    }
    setIsLoading(true);
    try {
      const result = await utils.customer.checkExists.fetch({ phoneNumber });
      if (result.exists) {
        setLoginStep("pin");
      } else {
        setLoginStep("register");
      }
    } catch {
      setLoginStep("register");
    } finally {
      setIsLoading(false);
    }
  };

  const handleCustomerPinSubmit = async () => {
    if (pin.length !== 6) {
      toast.error("กรุณากรอก PIN 6 หลัก");
      return;
    }
    setIsLoading(true);
    try {
      const result = await verifyPinMutation.mutateAsync({ phoneNumber, pin });
      toast.success(`ยินดีต้อนรับ ${result.name}`);
      sessionStorage.setItem("customerId", String(result.customerId));
      sessionStorage.setItem("customerName", result.name);
      setLocation("/customer-profile");
    } catch (error: any) {
      toast.error(error.message || "PIN ไม่ถูกต้อง");
      setPin("");
    } finally {
      setIsLoading(false);
    }
  };

  const handleCustomerRegister = async () => {
    if (!name.trim()) { toast.error("กรุณากรอกชื่อ"); return; }
    if (pin.length !== 6) { toast.error("กรุณากรอก PIN 6 หลัก"); return; }
    setIsLoading(true);
    try {
      const result = await createCustomerMutation.mutateAsync({ phoneNumber, name, email: email || undefined, pin });
      toast.success("สมัครสมาชิกสำเร็จ!");
      sessionStorage.setItem("customerId", String(result?.id));
      sessionStorage.setItem("customerName", name);
      setLocation("/customer-profile");
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาด");
    } finally {
      setIsLoading(false);
    }
  };

  const handleAdminPhoneSubmit = () => {
    if (!phoneNumber.match(/^\d{10}$/)) {
      toast.error("กรุณากรอกเบอร์โทรศัพท์ 10 หลัก");
      return;
    }
    setLoginStep("admin-pin");
  };

  const handleAdminPinSubmit = async () => {
    if (pin.length !== 6) {
      toast.error("กรุณากรอก PIN 6 หลัก");
      return;
    }
    setIsLoading(true);
    try {
      const result = await adminVerifyPinMutation.mutateAsync({ phoneNumber, pin });
      toast.success(`ยินดีต้อนรับ ${result.name}`);
      sessionStorage.setItem("adminId", String(result.adminId));
      sessionStorage.setItem("adminName", result.name);
      sessionStorage.setItem("adminRole", result.role);
      if (result.role === "super_admin") {
        setLocation("/super-admin");
      } else {
        setLocation("/admin-dashboard");
      }
    } catch (error: any) {
      toast.error(error.message || "PIN ไม่ถูกต้อง");
      setPin("");
    } finally {
      setIsLoading(false);
    }
  };

  const resetLogin = () => {
    setLoginStep("type");
    setUserType(null);
    setPhoneNumber("");
    setPin("");
    setName("");
    setEmail("");
  };

  return (
    <div className="art-deco-bg min-h-screen flex items-center justify-center p-4">
      <div className="max-w-md w-full space-y-6">
        {loginStep !== "type" && (
          <button
            onClick={resetLogin}
            className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors"
          >
            <LogOut size={20} />
            กลับ
          </button>
        )}

        {/* Select Type */}
        {loginStep === "type" && (
          <>
            <div className="text-center space-y-2">
              <div className="flex justify-center mb-3">
                <div className="w-16 h-16 rounded-full bg-yellow-100 flex items-center justify-center">
                  <Crown className="text-yellow-700" size={32} />
                </div>
              </div>
              <h1 className="text-4xl font-bold text-gradient">เข้าสู่ระบบ</h1>
              <p className="text-slate-600">เลือกประเภทการเข้าสู่ระบบ</p>
            </div>

            <div className="space-y-3">
              <Button
                onClick={() => { setUserType("customer"); setLoginStep("phone"); }}
                className="w-full btn-gold py-6 text-lg"
              >
                <User size={20} className="mr-2" />
                สมาชิก
              </Button>
              <Button
                onClick={() => { setUserType("admin"); setLoginStep("phone"); }}
                variant="outline"
                className="w-full border-yellow-500/40 text-yellow-700 hover:bg-yellow-50 py-6 text-lg"
              >
                <ShieldCheck size={20} className="mr-2" />
                ผู้ดูแล
              </Button>
            </div>
          </>
        )}

        {/* Customer Phone */}
        {userType === "customer" && loginStep === "phone" && (
          <LuxuryCard>
            <LuxuryCardHeader>
              <LuxuryCardTitle>เบอร์โทรศัพท์</LuxuryCardTitle>
            </LuxuryCardHeader>
            <LuxuryCardContent>
              <Input
                type="tel"
                placeholder="0xxxxxxxxx"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, "").slice(0, 10))}
                maxLength={10}
                disabled={isLoading}
                className="text-center text-xl tracking-widest"
              />
              <Button
                onClick={handleCustomerPhoneSubmit}
                disabled={isLoading || phoneNumber.length !== 10}
                className="w-full btn-gold"
              >
                {isLoading ? "กำลังตรวจสอบ..." : "ต่อไป"}
              </Button>
            </LuxuryCardContent>
          </LuxuryCard>
        )}

        {/* Customer PIN */}
        {userType === "customer" && loginStep === "pin" && (
          <LuxuryCard>
            <LuxuryCardHeader>
              <LuxuryCardTitle>กรอก PIN</LuxuryCardTitle>
              <p className="text-sm text-slate-500 mt-1">{phoneNumber}</p>
            </LuxuryCardHeader>
            <LuxuryCardContent>
              <OnScreenKeypad value={pin} onChange={setPin} maxLength={6} disabled={isLoading} />
              <Button
                onClick={handleCustomerPinSubmit}
                disabled={isLoading || pin.length !== 6}
                className="w-full btn-gold"
              >
                {isLoading ? "กำลังเข้าสู่ระบบ..." : "เข้าสู่ระบบ"}
              </Button>
            </LuxuryCardContent>
          </LuxuryCard>
        )}

        {/* Customer Register */}
        {userType === "customer" && loginStep === "register" && (
          <LuxuryCard>
            <LuxuryCardHeader>
              <LuxuryCardTitle>สมัครสมาชิก</LuxuryCardTitle>
              <p className="text-sm text-slate-500 mt-1">{phoneNumber}</p>
            </LuxuryCardHeader>
            <LuxuryCardContent>
              <Input
                placeholder="ชื่อ-นามสกุล *"
                value={name}
                onChange={(e) => setName(e.target.value)}
                disabled={isLoading}
              />
              <Input
                type="email"
                placeholder="อีเมล (ไม่บังคับ)"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={isLoading}
              />
              <div>
                <p className="text-sm font-medium text-slate-700 mb-2 text-center">ตั้ง PIN 6 หลัก</p>
                <OnScreenKeypad value={pin} onChange={setPin} maxLength={6} disabled={isLoading} />
              </div>
              <Button
                onClick={handleCustomerRegister}
                disabled={isLoading || !name || pin.length !== 6}
                className="w-full btn-gold"
              >
                {isLoading ? "กำลังสมัคร..." : "สมัครสมาชิก"}
              </Button>
            </LuxuryCardContent>
          </LuxuryCard>
        )}

        {/* Admin Phone */}
        {userType === "admin" && loginStep === "phone" && (
          <LuxuryCard>
            <LuxuryCardHeader>
              <LuxuryCardTitle>เบอร์โทรศัพท์</LuxuryCardTitle>
            </LuxuryCardHeader>
            <LuxuryCardContent>
              <Input
                type="tel"
                placeholder="0xxxxxxxxx"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, "").slice(0, 10))}
                maxLength={10}
                className="text-center text-xl tracking-widest"
              />
              <Button
                onClick={handleAdminPhoneSubmit}
                disabled={phoneNumber.length !== 10}
                className="w-full btn-gold"
              >
                ต่อไป
              </Button>
            </LuxuryCardContent>
          </LuxuryCard>
        )}

        {/* Admin PIN */}
        {userType === "admin" && loginStep === "admin-pin" && (
          <LuxuryCard>
            <LuxuryCardHeader>
              <LuxuryCardTitle>กรอก PIN</LuxuryCardTitle>
              <p className="text-sm text-slate-500 mt-1">{phoneNumber}</p>
            </LuxuryCardHeader>
            <LuxuryCardContent>
              <OnScreenKeypad value={pin} onChange={setPin} maxLength={6} disabled={isLoading} />
              <Button
                onClick={handleAdminPinSubmit}
                disabled={isLoading || pin.length !== 6}
                className="w-full btn-gold"
              >
                {isLoading ? "กำลังเข้าสู่ระบบ..." : "เข้าสู่ระบบ"}
              </Button>
            </LuxuryCardContent>
          </LuxuryCard>
        )}
      </div>
    </div>
  );
}
