import React, { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { OnScreenKeypad } from "@/components/OnScreenKeypad";
import { LuxuryCard, LuxuryCardContent, LuxuryCardHeader, LuxuryCardTitle } from "@/components/LuxuryCard";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ArrowLeft, User } from "lucide-react";

type Step = "phone" | "pin" | "register";

export default function CustomerLogin() {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState<Step>("phone");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [pin, setPin] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const verifyPinMutation = trpc.customer.verifyPin.useMutation();
  const createCustomerMutation = trpc.customer.create.useMutation();
  const utils = trpc.useUtils();

  const handlePhoneSubmit = async () => {
    if (!phoneNumber.match(/^\d{10}$/)) {
      toast.error("กรุณากรอกเบอร์โทรศัพท์ 10 หลัก");
      return;
    }
    setIsLoading(true);
    try {
      const result = await utils.customer.checkExists.fetch({ phoneNumber });
      if (result.exists) {
        setStep("pin");
      } else {
        setStep("register");
      }
    } catch {
      setStep("register");
    } finally {
      setIsLoading(false);
    }
  };

  const handlePinSubmit = async () => {
    if (pin.length !== 6) {
      toast.error("กรุณากรอก PIN 6 หลัก");
      return;
    }
    setIsLoading(true);
    try {
      const result = await verifyPinMutation.mutateAsync({ phoneNumber, pin });
      toast.success(`ยินดีต้อนรับ ${result.name}`);
      sessionStorage.setItem("customerId", String(result.customerId));
      sessionStorage.setItem("customerName", result.name);
      setLocation("/customer-profile");
    } catch (error: any) {
      toast.error(error.message || "PIN ไม่ถูกต้อง");
      setPin("");
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = async () => {
    if (!name.trim()) { toast.error("กรุณากรอกชื่อ"); return; }
    if (pin.length !== 6) { toast.error("กรุณากรอก PIN 6 หลัก"); return; }
    setIsLoading(true);
    try {
      const result = await createCustomerMutation.mutateAsync({ phoneNumber, name, email: email || undefined, pin });
      toast.success("สมัครสมาชิกสำเร็จ!");
      sessionStorage.setItem("customerId", String(result?.id));
      sessionStorage.setItem("customerName", name);
      setLocation("/customer-profile");
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาด");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="art-deco-bg min-h-screen flex items-center justify-center p-4">
      <div className="max-w-md w-full space-y-6">
        <button
          onClick={() => { if (step === "phone") setLocation("/login"); else { setStep("phone"); setPin(""); } }}
          className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors"
        >
          <ArrowLeft size={20} />
          กลับ
        </button>

        <div className="text-center space-y-2">
          <div className="flex justify-center mb-3">
            <div className="w-16 h-16 rounded-full bg-yellow-100 flex items-center justify-center">
              <User className="text-yellow-700" size={32} />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gradient">สมาชิก</h1>
          <p className="text-slate-600">เข้าสู่ระบบหรือสมัครสมาชิก</p>
        </div>

        {step === "phone" && (
          <LuxuryCard>
            <LuxuryCardHeader>
              <LuxuryCardTitle>เบอร์โทรศัพท์</LuxuryCardTitle>
            </LuxuryCardHeader>
            <LuxuryCardContent>
              <Input
                type="tel"
                placeholder="0xxxxxxxxx"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, "").slice(0, 10))}
                maxLength={10}
                disabled={isLoading}
                className="text-center text-xl tracking-widest"
              />
              <Button
                onClick={handlePhoneSubmit}
                disabled={isLoading || phoneNumber.length !== 10}
                className="w-full btn-gold"
              >
                {isLoading ? "กำลังตรวจสอบ..." : "ต่อไป"}
              </Button>
            </LuxuryCardContent>
          </LuxuryCard>
        )}

        {step === "pin" && (
          <LuxuryCard>
            <LuxuryCardHeader>
              <LuxuryCardTitle>กรอก PIN</LuxuryCardTitle>
              <p className="text-sm text-slate-500 mt-1">{phoneNumber}</p>
            </LuxuryCardHeader>
            <LuxuryCardContent>
              <OnScreenKeypad value={pin} onChange={setPin} maxLength={6} disabled={isLoading} />
              <Button
                onClick={handlePinSubmit}
                disabled={isLoading || pin.length !== 6}
                className="w-full btn-gold"
              >
                {isLoading ? "กำลังเข้าสู่ระบบ..." : "เข้าสู่ระบบ"}
              </Button>
            </LuxuryCardContent>
          </LuxuryCard>
        )}

        {step === "register" && (
          <LuxuryCard>
            <LuxuryCardHeader>
              <LuxuryCardTitle>สมัครสมาชิก</LuxuryCardTitle>
              <p className="text-sm text-slate-500 mt-1">{phoneNumber}</p>
            </LuxuryCardHeader>
            <LuxuryCardContent>
              <Input
                placeholder="ชื่อ-นามสกุล *"
                value={name}
                onChange={(e) => setName(e.target.value)}
                disabled={isLoading}
              />
              <Input
                type="email"
                placeholder="อีเมล (ไม่บังคับ)"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={isLoading}
              />
              <div>
                <p className="text-sm font-medium text-slate-700 mb-2 text-center">ตั้ง PIN 6 หลัก</p>
                <OnScreenKeypad value={pin} onChange={setPin} maxLength={6} disabled={isLoading} />
              </div>
              <Button
                onClick={handleRegister}
                disabled={isLoading || !name || pin.length !== 6}
                className="w-full btn-gold"
              >
                {isLoading ? "กำลังสมัคร..." : "สมัครสมาชิก"}
              </Button>
            </LuxuryCardContent>
          </LuxuryCard>
        )}
      </div>
    </div>
  );
}
