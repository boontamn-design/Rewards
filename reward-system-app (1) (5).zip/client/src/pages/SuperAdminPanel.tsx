import React, { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { LuxuryCard, LuxuryCardContent, LuxuryCardHeader, LuxuryCardTitle } from "@/components/LuxuryCard";
import { TierBadge } from "@/components/TierBadge";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ArrowLeft, Plus, Edit, Trash2, Gift, Crown, Shield, ChevronDown, ChevronUp } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function SuperAdminPanel() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    const id = sessionStorage.getItem("adminId");
    const role = sessionStorage.getItem("adminRole");
    const sessionTime = sessionStorage.getItem("adminSessionTime");
    
    if (sessionTime) {
      const elapsed = Date.now() - Number(sessionTime);
      const sessionExpiration = 24 * 60 * 60 * 1000;
      if (elapsed > sessionExpiration) {
        sessionStorage.clear();
        setLocation("/");
        return;
      }
    }
    
    if (!id || role !== "super_admin") { setLocation("/"); return; }
  }, []);

  // Reward state
  const [rewardDialog, setRewardDialog] = useState<"create" | "edit" | null>(null);
  const [editingReward, setEditingReward] = useState<any>(null);
  const [rewardForm, setRewardForm] = useState({ name: "", description: "", pointsRequired: "", quantity: "", category: "", isActive: true });

  // Tier state
  const [tierDialog, setTierDialog] = useState<"create" | "edit" | null>(null);
  const [editingTier, setEditingTier] = useState<any>(null);
  const [tierForm, setTierForm] = useState({ name: "", minPoints: "", maxPoints: "", description: "", benefits: "", color: "", icon: "" });

  // Admin state
  const [adminDialog, setAdminDialog] = useState(false);
  const [adminForm, setAdminForm] = useState({ phoneNumber: "", name: "", pin: "", role: "admin" as "admin" | "super_admin" });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data: rewards, refetch: refetchRewards } = trpc.superAdmin.getRewards.useQuery();
  const { data: tiers, refetch: refetchTiers } = trpc.superAdmin.getRewardTiers.useQuery();
  const { data: admins, refetch: refetchAdmins } = trpc.superAdmin.getAllAdmins.useQuery();

  const createRewardMutation = trpc.superAdmin.createReward.useMutation();
  const updateRewardMutation = trpc.superAdmin.updateReward.useMutation();
  const deleteRewardMutation = trpc.superAdmin.deleteReward.useMutation();
  const createTierMutation = trpc.superAdmin.createRewardTier.useMutation();
  const updateTierMutation = trpc.superAdmin.updateRewardTier.useMutation();
  const deleteTierMutation = trpc.superAdmin.deleteRewardTier.useMutation();
  const createAdminMutation = trpc.superAdmin.createAdmin.useMutation();

  const openCreateReward = () => {
    setRewardForm({ name: "", description: "", pointsRequired: "", quantity: "", category: "", isActive: true });
    setEditingReward(null);
    setRewardDialog("create");
  };

  const openEditReward = (reward: any) => {
    setRewardForm({
      name: reward.name,
      description: reward.description || "",
      pointsRequired: String(reward.pointsRequired),
      quantity: reward.quantity ? String(reward.quantity) : "",
      category: reward.category || "",
      isActive: reward.isActive,
    });
    setEditingReward(reward);
    setRewardDialog("edit");
  };

  const handleSaveReward = async () => {
    if (!rewardForm.name || !rewardForm.pointsRequired) { toast.error("กรุณากรอกข้อมูลที่จำเป็น"); return; }
    setIsSubmitting(true);
    try {
      if (rewardDialog === "create") {
        await createRewardMutation.mutateAsync({
          name: rewardForm.name,
          description: rewardForm.description || undefined,
          pointsRequired: parseInt(rewardForm.pointsRequired),
          quantity: rewardForm.quantity ? parseInt(rewardForm.quantity) : undefined,
          category: rewardForm.category || undefined,
        });
        toast.success("สร้างรางวัลสำเร็จ");
      } else {
        await updateRewardMutation.mutateAsync({
          rewardId: editingReward.id,
          name: rewardForm.name,
          description: rewardForm.description || undefined,
          pointsRequired: parseInt(rewardForm.pointsRequired),
          quantity: rewardForm.quantity ? parseInt(rewardForm.quantity) : undefined,
          category: rewardForm.category || undefined,
          isActive: rewardForm.isActive,
        });
        toast.success("แก้ไขรางวัลสำเร็จ");
      }
      setRewardDialog(null);
      refetchRewards();
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาด");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteReward = async (rewardId: number) => {
    if (!confirm("ยืนยันการปิดรางวัลนี้?")) return;
    try {
      await deleteRewardMutation.mutateAsync({ rewardId });
      toast.success("ปิดรางวัลสำเร็จ");
      refetchRewards();
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาด");
    }
  };

  const openCreateTier = () => {
    setTierForm({ name: "", minPoints: "", maxPoints: "", description: "", benefits: "", color: "#FFD700", icon: "" });
    setEditingTier(null);
    setTierDialog("create");
  };

  const openEditTier = (tier: any) => {
    const benefits = Array.isArray(tier.benefits) ? tier.benefits.join(", ") : (typeof tier.benefits === "string" ? JSON.parse(tier.benefits || "[]").join(", ") : "");
    setTierForm({
      name: tier.name,
      minPoints: String(tier.minPoints),
      maxPoints: tier.maxPoints ? String(tier.maxPoints) : "",
      description: tier.description || "",
      benefits,
      color: tier.color || "#FFD700",
      icon: tier.icon || "",
    });
    setEditingTier(tier);
    setTierDialog("edit");
  };

  const handleSaveTier = async () => {
    if (!tierForm.name || !tierForm.minPoints) { toast.error("กรุณากรอกข้อมูลที่จำเป็น"); return; }
    setIsSubmitting(true);
    try {
      const benefits = tierForm.benefits ? tierForm.benefits.split(",").map(b => b.trim()).filter(Boolean) : [];
      if (tierDialog === "create") {
        await createTierMutation.mutateAsync({
          name: tierForm.name,
          minPoints: parseInt(tierForm.minPoints),
          maxPoints: tierForm.maxPoints ? parseInt(tierForm.maxPoints) : undefined,
          description: tierForm.description || undefined,
          benefits,
          color: tierForm.color || undefined,
          icon: tierForm.icon || undefined,
        });
        toast.success("สร้าง Tier สำเร็จ");
      } else {
        await updateTierMutation.mutateAsync({
          tierId: editingTier.id,
          name: tierForm.name,
          minPoints: parseInt(tierForm.minPoints),
          maxPoints: tierForm.maxPoints ? parseInt(tierForm.maxPoints) : undefined,
          description: tierForm.description || undefined,
          benefits,
          color: tierForm.color || undefined,
          icon: tierForm.icon || undefined,
        });
        toast.success("แก้ไข Tier สำเร็จ");
      }
      setTierDialog(null);
      refetchTiers();
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาด");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteTier = async (tierId: number) => {
    if (!confirm("ยืนยันการลบ Tier นี้?")) return;
    try {
      await deleteTierMutation.mutateAsync({ tierId });
      toast.success("ลบ Tier สำเร็จ");
      refetchTiers();
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาด");
    }
  };

  const handleCreateAdmin = async () => {
    if (!adminForm.phoneNumber || !adminForm.name || !adminForm.pin) { toast.error("กรุณากรอกข้อมูลให้ครบ"); return; }
    if (adminForm.pin.length !== 6) { toast.error("PIN ต้องมี 6 หลัก"); return; }
    setIsSubmitting(true);
    try {
      await createAdminMutation.mutateAsync(adminForm);
      toast.success("สร้าง Admin สำเร็จ");
      setAdminDialog(false);
      setAdminForm({ phoneNumber: "", name: "", pin: "", role: "admin" });
      refetchAdmins();
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาด");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem("adminId");
    sessionStorage.removeItem("adminName");
    sessionStorage.removeItem("adminRole");
    sessionStorage.removeItem("adminSessionTime");
    setLocation("/");
  };

  return (
    <div className="art-deco-bg min-h-screen p-4 pb-20">
      <div className="max-w-3xl mx-auto space-y-5">
        <div className="flex items-center gap-3 pt-2">
          <button onClick={() => setLocation("/admin-dashboard")} className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors">
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-gradient">Super Admin</h1>
            <p className="text-xs text-slate-500">จัดการรางวัล, Tier และผู้ดูแลระบบ</p>
          </div>
        </div>

        <Tabs defaultValue="rewards">
          <TabsList className="w-full">
            <TabsTrigger value="rewards" className="flex-1 gap-2"><Gift size={14} />เพิ่มรางวัล</TabsTrigger>
            <TabsTrigger value="tiers" className="flex-1 gap-2"><Crown size={14} />เพิ่มระดับ</TabsTrigger>
            <TabsTrigger value="admins" className="flex-1 gap-2"><Shield size={14} />เพิ่มคะแนน</TabsTrigger>
          </TabsList>

          {/* Rewards Tab */}
          <TabsContent value="rewards" className="space-y-4 mt-4">
            <div className="flex justify-end">
              <Button onClick={openCreateReward} className="btn-gold gap-2">
                <Plus size={16} />
                เพิ่มรางวัล
              </Button>
            </div>
            {!rewards ? (
              <div className="text-center py-8"><div className="w-10 h-10 border-4 border-yellow-500 border-t-transparent rounded-full animate-spin mx-auto" /></div>
            ) : rewards.length === 0 ? (
              <LuxuryCard className="text-center py-8"><p className="text-slate-500">ยังไม่มีรางวัล</p></LuxuryCard>
            ) : (
              <div className="space-y-3">
                {rewards.map((r) => (
                  <LuxuryCard key={r.id} className={!r.isActive ? "opacity-60" : ""}>
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="font-bold">{r.name}</p>
                          {!r.isActive && <span className="text-xs px-2 py-0.5 rounded-full bg-red-100 text-red-600">ปิดใช้งาน</span>}
                        </div>
                        {r.description && <p className="text-sm text-slate-500">{r.description}</p>}
                        <div className="flex gap-3 mt-1 text-xs text-slate-400">
                          <span>{r.pointsRequired.toLocaleString()} แต้ม</span>
                          {r.category && <span>· {r.category}</span>}
                          {r.quantityRemaining !== null && r.quantityRemaining !== undefined && <span>· เหลือ {r.quantityRemaining}</span>}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button onClick={() => openEditReward(r)} variant="outline" size="sm" className="border-yellow-500/30"><Edit size={14} /></Button>
                        <Button onClick={() => handleDeleteReward(r.id)} variant="outline" size="sm" className="border-red-300 text-red-600 hover:bg-red-50"><Trash2 size={14} /></Button>
                      </div>
                    </div>
                  </LuxuryCard>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Tiers Tab */}
          <TabsContent value="tiers" className="space-y-4 mt-4">
            <div className="flex justify-end">
              <Button onClick={openCreateTier} className="btn-gold gap-2">
                <Plus size={16} />
                เพิ่ม Tier
              </Button>
            </div>
            {!tiers ? (
              <div className="text-center py-8"><div className="w-10 h-10 border-4 border-yellow-500 border-t-transparent rounded-full animate-spin mx-auto" /></div>
            ) : tiers.length === 0 ? (
              <LuxuryCard className="text-center py-8"><p className="text-slate-500">ยังไม่มี Tier</p></LuxuryCard>
            ) : (
              <div className="space-y-3">
                {tiers.map((t) => (
                  <LuxuryCard key={t.id}>
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <TierBadge tierName={t.name} />
                        <div className="flex gap-3 mt-2 text-xs text-slate-500">
                          <span>{t.minPoints.toLocaleString()} แต้ม</span>
                          {t.maxPoints && <span>- {t.maxPoints.toLocaleString()} แต้ม</span>}
                          {!t.maxPoints && <span>ขึ้นไป</span>}
                        </div>
                        {t.description && <p className="text-xs text-slate-400 mt-1">{t.description}</p>}
                      </div>
                      <div className="flex gap-2">
                        <Button onClick={() => openEditTier(t)} variant="outline" size="sm" className="border-yellow-500/30"><Edit size={14} /></Button>
                        <Button onClick={() => handleDeleteTier(t.id)} variant="outline" size="sm" className="border-red-300 text-red-600 hover:bg-red-50"><Trash2 size={14} /></Button>
                      </div>
                    </div>
                  </LuxuryCard>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Admins Tab */}
          <TabsContent value="admins" className="space-y-4 mt-4">
            <div className="flex justify-end">
              <Button onClick={() => setAdminDialog(true)} className="btn-gold gap-2">
                <Plus size={16} />
                เพิ่ม Admin
              </Button>
            </div>
            {!admins ? (
              <div className="text-center py-8"><div className="w-10 h-10 border-4 border-yellow-500 border-t-transparent rounded-full animate-spin mx-auto" /></div>
            ) : admins.length === 0 ? (
              <LuxuryCard className="text-center py-8"><p className="text-slate-500">ยังไม่มี Admin</p></LuxuryCard>
            ) : (
              <div className="space-y-3">
                {admins.map((a) => (
                  <LuxuryCard key={a.id}>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-bold">{a.name}</p>
                        <p className="text-sm text-slate-500">{a.phoneNumber}</p>
                      </div>
                      <span className={`status-badge ${a.role === "super_admin" ? "bg-yellow-100 text-yellow-800 border border-yellow-300" : "bg-slate-100 text-slate-700 border border-slate-300"}`}>
                        {a.role === "super_admin" ? "Super Admin" : "Admin"}
                      </span>
                    </div>
                  </LuxuryCard>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Reward Dialog */}
      <Dialog open={!!rewardDialog} onOpenChange={() => setRewardDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{rewardDialog === "create" ? "เพิ่มรางวัล" : "แก้ไขรางวัล"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <Input placeholder="ชื่อรางวัล *" value={rewardForm.name} onChange={(e) => setRewardForm(f => ({ ...f, name: e.target.value }))} />
            <Input placeholder="คำอธิบาย" value={rewardForm.description} onChange={(e) => setRewardForm(f => ({ ...f, description: e.target.value }))} />
            <Input type="number" placeholder="แต้มที่ต้องใช้ *" value={rewardForm.pointsRequired} onChange={(e) => setRewardForm(f => ({ ...f, pointsRequired: e.target.value }))} />
            <Input type="number" placeholder="จำนวน (ว่างหากไม่จำกัด)" value={rewardForm.quantity} onChange={(e) => setRewardForm(f => ({ ...f, quantity: e.target.value }))} />
            <Input placeholder="หมวดหมู่ (เช่น discount, food)" value={rewardForm.category} onChange={(e) => setRewardForm(f => ({ ...f, category: e.target.value }))} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRewardDialog(null)}>ยกเลิก</Button>
            <Button onClick={handleSaveReward} disabled={isSubmitting} className="btn-gold">
              {isSubmitting ? "กำลังบันทึก..." : "บันทึก"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Tier Dialog */}
      <Dialog open={!!tierDialog} onOpenChange={() => setTierDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{tierDialog === "create" ? "เพิ่ม Tier" : "แก้ไข Tier"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <Input placeholder="ชื่อ Tier *" value={tierForm.name} onChange={(e) => setTierForm(f => ({ ...f, name: e.target.value }))} />
            <Input type="number" placeholder="แต้มขั้นต่ำ *" value={tierForm.minPoints} onChange={(e) => setTierForm(f => ({ ...f, minPoints: e.target.value }))} />
            <Input type="number" placeholder="แต้มสูงสุด (ว่างหากไม่มีขีดจำกัด)" value={tierForm.maxPoints} onChange={(e) => setTierForm(f => ({ ...f, maxPoints: e.target.value }))} />
            <Input placeholder="คำอธิบาย" value={tierForm.description} onChange={(e) => setTierForm(f => ({ ...f, description: e.target.value }))} />
            <Input placeholder="สิทธิพิเศษ (คั่นด้วย ,)" value={tierForm.benefits} onChange={(e) => setTierForm(f => ({ ...f, benefits: e.target.value }))} />
            <Input placeholder="สีเช่น #FFD700" value={tierForm.color} onChange={(e) => setTierForm(f => ({ ...f, color: e.target.value }))} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setTierDialog(null)}>ยกเลิก</Button>
            <Button onClick={handleSaveTier} disabled={isSubmitting} className="btn-gold">
              {isSubmitting ? "กำลังบันทึก..." : "บันทึก"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Admin Dialog */}
      <Dialog open={adminDialog} onOpenChange={() => setAdminDialog(false)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>เพิ่ม Admin</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <Input type="tel" placeholder="เบอร์โทรศัพท์ *" value={adminForm.phoneNumber} onChange={(e) => setAdminForm(f => ({ ...f, phoneNumber: e.target.value.replace(/\D/g, "").slice(0, 10) }))} />
            <Input placeholder="ชื่อ *" value={adminForm.name} onChange={(e) => setAdminForm(f => ({ ...f, name: e.target.value }))} />
            <Input type="password" placeholder="PIN 6 หลัก *" value={adminForm.pin} onChange={(e) => setAdminForm(f => ({ ...f, pin: e.target.value.replace(/\D/g, "").slice(0, 6) }))} maxLength={6} />
            <select
              value={adminForm.role}
              onChange={(e) => setAdminForm(f => ({ ...f, role: e.target.value as "admin" | "super_admin" }))}
              className="w-full border border-input rounded-md px-3 py-2 text-sm bg-background"
            >
              <option value="admin">Admin</option>
              <option value="super_admin">Super Admin</option>
            </select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAdminDialog(false)}>ยกเลิก</Button>
            <Button onClick={handleCreateAdmin} disabled={isSubmitting} className="btn-gold">
              {isSubmitting ? "กำลังสร้าง..." : "สร้าง Admin"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
