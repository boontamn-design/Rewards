import React, { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { LuxuryCard, LuxuryCardContent, LuxuryCardHeader, LuxuryCardTitle } from "@/components/LuxuryCard";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { ArrowLeft, Gift, Star, AlertCircle } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function RewardsShop() {
  const [, setLocation] = useLocation();
  const [customerId, setCustomerId] = useState<number | null>(null);
  const [selectedReward, setSelectedReward] = useState<any>(null);
  const [isRedeeming, setIsRedeeming] = useState(false);

  useEffect(() => {
    const id = sessionStorage.getItem("customerId");
    if (!id) { setLocation("/login"); return; }
    setCustomerId(Number(id));
  }, []);

  const { data: rewards, isLoading } = trpc.reward.getAvailable.useQuery();
  const { data: profile } = trpc.customer.getProfile.useQuery(
    { customerId: customerId || 0 },
    { enabled: !!customerId }
  );

  const redeemMutation = trpc.customer.redeem.useMutation();
  const utils = trpc.useUtils();

  const handleRedeem = async () => {
    if (!selectedReward || !customerId) return;
    setIsRedeeming(true);
    try {
      await redeemMutation.mutateAsync({ customerId, rewardId: selectedReward.id });
      toast.success("ส่งคำขอแลกรางวัลสำเร็จ! รอการอนุมัติจาก Admin");
      utils.customer.getProfile.invalidate();
      setSelectedReward(null);
    } catch (error: any) {
      toast.error(error.message || "เกิดข้อผิดพลาด");
    } finally {
      setIsRedeeming(false);
    }
  };

  const canAfford = (pointsRequired: number) => (profile?.totalPoints || 0) >= pointsRequired;

  return (
    <div className="art-deco-bg min-h-screen p-4 pb-20">
      <div className="max-w-2xl mx-auto space-y-5">
        <div className="flex items-center gap-3 pt-2">
          <button onClick={() => setLocation("/customer-profile")} className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors">
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-gradient">ร้านค้ารางวัล</h1>
            {profile && (
              <p className="text-sm text-slate-500">แต้มของคุณ: <span className="font-bold text-yellow-700">{profile.totalPoints.toLocaleString()}</span> แต้ม</p>
            )}
          </div>
        </div>

        {isLoading ? (
          <div className="text-center py-12">
            <div className="w-12 h-12 border-4 border-yellow-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
            <p className="text-slate-500">กำลังโหลดรางวัล...</p>
          </div>
        ) : !rewards || rewards.length === 0 ? (
          <LuxuryCard className="text-center py-12">
            <Gift size={48} className="text-yellow-500/40 mx-auto mb-3" />
            <p className="text-slate-500">ยังไม่มีรางวัลในขณะนี้</p>
          </LuxuryCard>
        ) : (
          <div className="grid gap-4">
            {rewards.map((reward) => {
              const affordable = canAfford(reward.pointsRequired);
              return (
                <LuxuryCard key={reward.id} className={!affordable ? "opacity-70" : ""}>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Gift size={18} className="text-yellow-600" />
                        <h3 className="font-bold text-lg">{reward.name}</h3>
                      </div>
                      {reward.description && (
                        <p className="text-sm text-slate-500 mb-2">{reward.description}</p>
                      )}
                      {reward.category && (
                        <span className="text-xs px-2 py-1 rounded-full bg-yellow-100 text-yellow-700 border border-yellow-300">
                          {reward.category}
                        </span>
                      )}
                    </div>
                    <div className="text-right flex-shrink-0">
                      <div className="flex items-center gap-1 justify-end mb-2">
                        <Star size={14} className="text-yellow-600" />
                        <span className="font-bold text-xl text-yellow-700">{reward.pointsRequired.toLocaleString()}</span>
                        <span className="text-xs text-slate-500">แต้ม</span>
                      </div>
                      {reward.quantityRemaining !== null && reward.quantityRemaining !== undefined && (
                        <p className="text-xs text-slate-400 mb-2">เหลือ {reward.quantityRemaining} ชิ้น</p>
                      )}
                      <Button
                        onClick={() => setSelectedReward(reward)}
                        disabled={!affordable || (reward.quantityRemaining !== null && reward.quantityRemaining !== undefined && reward.quantityRemaining <= 0)}
                        size="sm"
                        className={affordable ? "btn-gold" : "opacity-50 cursor-not-allowed"}
                      >
                        {!affordable ? "แต้มไม่พอ" : "แลกรางวัล"}
                      </Button>
                    </div>
                  </div>
                  {!affordable && (
                    <div className="mt-3 flex items-center gap-2 text-xs text-slate-500 bg-yellow-50/50 rounded-lg p-2">
                      <AlertCircle size={12} />
                      ต้องการแต้มเพิ่มอีก {(reward.pointsRequired - (profile?.totalPoints || 0)).toLocaleString()} แต้ม
                    </div>
                  )}
                </LuxuryCard>
              );
            })}
          </div>
        )}
      </div>

      <AlertDialog open={!!selectedReward} onOpenChange={() => setSelectedReward(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>ยืนยันการแลกรางวัล</AlertDialogTitle>
            <AlertDialogDescription>
              คุณต้องการแลก <strong>{selectedReward?.name}</strong> ใช้ <strong>{selectedReward?.pointsRequired?.toLocaleString()} แต้ม</strong> ใช่หรือไม่?
              <br /><br />
              หลังจากส่งคำขอ Admin จะตรวจสอบและอนุมัติภายใน 24 ชั่วโมง
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>ยกเลิก</AlertDialogCancel>
            <AlertDialogAction onClick={handleRedeem} disabled={isRedeeming} className="btn-gold">
              {isRedeeming ? "กำลังส่งคำขอ..." : "ยืนยัน"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
