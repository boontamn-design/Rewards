import React, { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { LuxuryCard, LuxuryCardContent, LuxuryCardHeader, LuxuryCardTitle } from "@/components/LuxuryCard";
import { TierBadge } from "@/components/TierBadge";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Users, TrendingUp, Gift, Clock, Star, CheckCircle, XCircle } from "lucide-react";

export default function AdminReports() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    const id = sessionStorage.getItem("adminId");
    if (!id) setLocation("/admin-login");
  }, []);

  const { data: stats, isLoading: statsLoading } = trpc.admin.getStatistics.useQuery();
  const { data: allCustomers, isLoading: customersLoading } = trpc.admin.getAllCustomers.useQuery();
  const { data: allRedemptions, isLoading: redemptionsLoading } = trpc.admin.getAllRedemptions.useQuery();
  const { data: tiers } = trpc.tier.getAll.useQuery();

  const isLoading = statsLoading || customersLoading || redemptionsLoading;

  // Compute tier distribution
  const tierDistribution = React.useMemo(() => {
    if (!allCustomers || !tiers) return [];
    return tiers.map((tier) => {
      const count = allCustomers.filter((c) => {
        if (tier.maxPoints) return c.totalPoints >= tier.minPoints && c.totalPoints <= tier.maxPoints;
        return c.totalPoints >= tier.minPoints;
      }).length;
      return { ...tier, count };
    });
  }, [allCustomers, tiers]);

  // Redemption stats
  const redemptionStats = React.useMemo(() => {
    if (!allRedemptions) return { pending: 0, approved: 0, rejected: 0, total: 0 };
    return {
      pending: allRedemptions.filter(r => r.status === "pending").length,
      approved: allRedemptions.filter(r => r.status === "approved").length,
      rejected: allRedemptions.filter(r => r.status === "rejected").length,
      total: allRedemptions.length,
    };
  }, [allRedemptions]);

  return (
    <div className="art-deco-bg min-h-screen p-4 pb-20">
      <div className="max-w-3xl mx-auto space-y-5">
        <div className="flex items-center gap-3 pt-2">
          <button onClick={() => setLocation("/admin-dashboard")} className="flex items-center gap-2 text-slate-600 hover:text-slate-900 transition-colors">
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-3xl font-bold text-gradient">รายงานสถิติ</h1>
        </div>

        {isLoading ? (
          <div className="text-center py-12">
            <div className="w-12 h-12 border-4 border-yellow-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
            <p className="text-slate-500">กำลังโหลด...</p>
          </div>
        ) : (
          <>
            {/* Overview Stats */}
            {stats && (
              <div className="grid grid-cols-2 gap-4">
                <LuxuryCard className="p-5">
                  <div className="flex items-center gap-3 mb-2">
                    <Users size={24} className="text-yellow-600" />
                    <p className="text-sm text-slate-500">ลูกค้าทั้งหมด</p>
                  </div>
                  <p className="text-4xl font-bold text-gradient">{stats.totalCustomers}</p>
                  <p className="text-xs text-slate-400 mt-1">ใช้งานอยู่ {stats.activeCustomers} คน</p>
                </LuxuryCard>

                <LuxuryCard className="p-5">
                  <div className="flex items-center gap-3 mb-2">
                    <Star size={24} className="text-yellow-600" />
                    <p className="text-sm text-slate-500">แต้มที่แจกทั้งหมด</p>
                  </div>
                  <p className="text-4xl font-bold text-gradient">{stats.totalPointsDistributed.toLocaleString()}</p>
                  <p className="text-xs text-slate-400 mt-1">แต้ม</p>
                </LuxuryCard>

                <LuxuryCard className="p-5">
                  <div className="flex items-center gap-3 mb-2">
                    <Gift size={24} className="text-blue-600" />
                    <p className="text-sm text-slate-500">แต้มที่แลกแล้ว</p>
                  </div>
                  <p className="text-4xl font-bold text-blue-600">{stats.totalPointsRedeemed.toLocaleString()}</p>
                  <p className="text-xs text-slate-400 mt-1">แต้ม</p>
                </LuxuryCard>

                <LuxuryCard className="p-5">
                  <div className="flex items-center gap-3 mb-2">
                    <Clock size={24} className="text-orange-600" />
                    <p className="text-sm text-slate-500">รอการอนุมัติ</p>
                  </div>
                  <p className="text-4xl font-bold text-orange-600">{stats.pendingRedemptions}</p>
                  <p className="text-xs text-slate-400 mt-1">รายการ</p>
                </LuxuryCard>
              </div>
            )}

            {/* Tier Distribution */}
            {tierDistribution.length > 0 && (
              <LuxuryCard>
                <LuxuryCardHeader>
                  <LuxuryCardTitle>การกระจายระดับสมาชิก</LuxuryCardTitle>
                </LuxuryCardHeader>
                <LuxuryCardContent>
                  <div className="space-y-4">
                    {tierDistribution.map((tier) => {
                      const pct = stats?.totalCustomers ? Math.round((tier.count / stats.totalCustomers) * 100) : 0;
                      return (
                        <div key={tier.id} className="space-y-1">
                          <div className="flex items-center justify-between">
                            <TierBadge tierName={tier.name} />
                            <span className="font-bold">{tier.count} คน ({pct}%)</span>
                          </div>
                          <div className="h-2 bg-yellow-100/30 rounded-full overflow-hidden border border-yellow-500/10">
                            <div
                              className="h-full bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full transition-all duration-700"
                              style={{ width: `${pct}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </LuxuryCardContent>
              </LuxuryCard>
            )}

            {/* Redemption Summary */}
            <LuxuryCard>
              <LuxuryCardHeader>
                <LuxuryCardTitle>สรุปการแลกรางวัล</LuxuryCardTitle>
              </LuxuryCardHeader>
              <LuxuryCardContent>
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-lg bg-yellow-50/50 border border-yellow-500/10 text-center">
                    <p className="text-2xl font-bold text-yellow-700">{redemptionStats.total}</p>
                    <p className="text-xs text-slate-500">ทั้งหมด</p>
                  </div>
                  <div className="p-3 rounded-lg bg-orange-50/50 border border-orange-200 text-center">
                    <p className="text-2xl font-bold text-orange-600">{redemptionStats.pending}</p>
                    <p className="text-xs text-slate-500">รอการอนุมัติ</p>
                  </div>
                  <div className="p-3 rounded-lg bg-green-50/50 border border-green-200 text-center">
                    <p className="text-2xl font-bold text-green-600">{redemptionStats.approved}</p>
                    <p className="text-xs text-slate-500">อนุมัติแล้ว</p>
                  </div>
                  <div className="p-3 rounded-lg bg-red-50/50 border border-red-200 text-center">
                    <p className="text-2xl font-bold text-red-600">{redemptionStats.rejected}</p>
                    <p className="text-xs text-slate-500">ปฏิเสธ</p>
                  </div>
                </div>
              </LuxuryCardContent>
            </LuxuryCard>

            {/* Top Customers */}
            {allCustomers && allCustomers.length > 0 && (
              <LuxuryCard>
                <LuxuryCardHeader>
                  <LuxuryCardTitle>Top 5 ลูกค้าแต้มสูงสุด</LuxuryCardTitle>
                </LuxuryCardHeader>
                <LuxuryCardContent>
                  <div className="space-y-2">
                    {[...allCustomers]
                      .sort((a, b) => b.totalPoints - a.totalPoints)
                      .slice(0, 5)
                      .map((c, i) => (
                        <div key={c.id} className="flex items-center justify-between p-3 rounded-lg bg-yellow-50/50 border border-yellow-500/10">
                          <div className="flex items-center gap-3">
                            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-sm font-bold ${i === 0 ? "bg-yellow-500 text-black" : i === 1 ? "bg-slate-300 text-slate-700" : i === 2 ? "bg-amber-600 text-white" : "bg-slate-100 text-slate-600"}`}>
                              {i + 1}
                            </div>
                            <div>
                              <p className="font-medium text-sm">{c.name}</p>
                              <p className="text-xs text-slate-400">{c.phoneNumber}</p>
                            </div>
                          </div>
                          <p className="font-bold text-yellow-700">{c.totalPoints.toLocaleString()} แต้ม</p>
                        </div>
                      ))}
                  </div>
                </LuxuryCardContent>
              </LuxuryCard>
            )}
          </>
        )}
      </div>
    </div>
  );
}
